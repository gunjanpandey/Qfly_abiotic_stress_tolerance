library(testthat)
library(ggalluvial)

test_check("ggalluvial")
