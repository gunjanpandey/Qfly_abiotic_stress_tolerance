#' Base ggproto classes for ggalluvial
#'
#' @name ggalluvial-ggproto
#' @seealso [`ggplot2::ggplot2-ggproto`]
#' @keywords internal
NULL
