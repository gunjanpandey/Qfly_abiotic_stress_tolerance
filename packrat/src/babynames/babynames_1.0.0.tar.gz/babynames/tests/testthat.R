library(testthat)
library(babynames)

test_check("babynames")
