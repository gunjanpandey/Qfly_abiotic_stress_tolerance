# babynames 1.0.0

* Add data validity/regression tests (@russellpierce, #27)

* Add data for 2016 and 2017. Minor changes to data from previous years to match external data sources. (@russellpierce, #30)

# babynames 0.3.0

* Update data for 2015 (@stillmatic, #16)

* Import from tibble in order to get consistent behaviour regardless of 
  whether or not tibble is attached.

# babynames 0.2.1

* Fix title in description 

# babynames 0.2.0

* Added a `NEWS.md` file to track changes to the package.

* Updated data for 2014 (#9)
