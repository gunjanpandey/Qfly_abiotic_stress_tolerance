`vcov.splm` <- function(object, ...) return(object$vcov)

