`bsjktest` <-
function(x,...){
  UseMethod("bsjktest")
}

