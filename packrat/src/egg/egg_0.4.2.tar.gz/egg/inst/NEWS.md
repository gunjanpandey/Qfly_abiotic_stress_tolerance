# gridExtra 0.4.2 (2018-11-02)
 
## NEW FEATURES

* added theme_article

# gridExtra 0.4.1 (2018-07-23)
 
## NEW FEATURES

* added tag_facet

## BUG FIX

* fixed aspect ratio for facetted plots was causing a problem in ggarrange; it now works again but the aspect ratio is not fully respected, as space between panels is ignored in the calculation

# gridExtra 0.4.0 (2018-06-18)
 
## NEW FEATURES

* added geom_custom
* ggarrange gains labels

## CLEANUP

* improved vignettes

## BUG FIX

* fixed aspect ratio somewhat better respected for facetted plots in ggarrange (not perfect, as space between panels is ignored in the calculation)

# gridExtra 0.2.0 (2017-09-12) 

* initial CRAN release

